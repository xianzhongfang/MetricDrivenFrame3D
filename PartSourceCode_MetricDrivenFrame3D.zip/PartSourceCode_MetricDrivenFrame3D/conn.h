/*
  This file is part of MetricDrivenFrame3D (Metric-Driven 3D Frame Field Generation).
  
  Copyright (C) 2022,  Xianzhong Fang
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

  * Redistributions of source code must retain the above copyright notice, this
  list of conditions and the following disclaimer.

  * Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.

  * Neither the name of the copyright holder nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  
  Author: Xianzhong Fang, Email: xzfangcs@163.com
*/



#ifndef CONN_FXZ_H
#define CONN_FXZ_H

namespace fxz {
  namespace frame3d {

    struct conn_data {
      size_t t[2];
      double logr[3];
    };

    int cal_halfsymmat_det(const fmatrixd& HM, double& det);
    int cal_mat3_det(const fmatrixd& M, double& det);
    int cal_inv_halfsymmat(const fmatrixd& HM, fmatrixd& MI);
    int cal_inv_mat3(const fmatrixd& M, fmatrixd& MI);
    int cal_conn_rot3d(const fmatrixd& u, fmatrixd& R);
    int get_tet_inner_faces(const fxz::mesh::tet_mesh& tm, fmatrixst& inner_faces);
    int read_conn3d(const std::string& in_file, std::vector<conn_data>& conn);
    int check_conn3d(const fxz::mesh::tet_mesh& tm, const std::vector<conn_data>& conn);

  } // namespace frame3d

} // namespace fxz


#endif
