/*
  This file is part of MetricDrivenFrame3D (Metric-Driven 3D Frame Field Generation).
  
  Copyright (C) 2022,  Xianzhong Fang
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

  * Redistributions of source code must retain the above copyright notice, this
  list of conditions and the following disclaimer.

  * Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.

  * Neither the name of the copyright holder nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  
  Author: Xianzhong Fang, Email: xzfangcs@163.com
*/



#include <iostream>
#include "ptree/ptree.h"

namespace fxz {
namespace frame3d {

int metric3d_maker_all(const boost::property_tree::ptree& para);
int conn3d_maker(const boost::property_tree::ptree& para);
int frame3d_maker(const boost::property_tree::ptree& para);
int ffc3d_maker(const boost::property_tree::ptree& para);
int matrix_binary_to_ascii(const boost::property_tree::ptree& para);
int matrix_ascii_to_binary(const boost::property_tree::ptree& para);

} // namespace frame3d
} // namespace fxz

int main(int argc, char* argv[])
{
  using boost::property_tree::ptree;
  ptree pt;

  zjucad::read_cmdline(argc, argv, pt);

  const std::string prog_name = pt.get<std::string>("prog.value");

#define CALL_SUB_PROG_WITH_NAME(pn, prog)       \
  if (pn == prog_name) return prog(pt);

  CALL_SUB_PROG_WITH_NAME("ffc3d", fxz::frame3d::ffc3d_maker);  
  CALL_SUB_PROG_WITH_NAME("metric3d_all", fxz::frame3d::metric3d_maker_all);
  CALL_SUB_PROG_WITH_NAME("conn3d", fxz::frame3d::conn3d_maker);
  CALL_SUB_PROG_WITH_NAME("frame3d", fxz::frame3d::frame3d_maker);
  CALL_SUB_PROG_WITH_NAME("mat_b2a", fxz::frame3d::matrix_binary_to_ascii);
  CALL_SUB_PROG_WITH_NAME("mat_a2b", fxz::frame3d::matrix_ascii_to_binary);
  
  std::cout << "# There is no program named " << prog_name << " ." << std::endl;

  return 0;
}

