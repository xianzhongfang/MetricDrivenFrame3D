Part of source code of paper "Metric-Driven 3D Frame Field Generation"
https://doi.org/10.1109/TVCG.2021.3136199

Author: Xianzhong Fang
Email: xzfangcs@163.com

This code can not be compiled because some third dependences can not be released.
