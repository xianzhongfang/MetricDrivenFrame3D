/*
  This file is part of MetricDrivenFrame3D (Metric-Driven 3D Frame Field Generation).
  
  Copyright (C) 2022,  Xianzhong Fang
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

  * Redistributions of source code must retain the above copyright notice, this
  list of conditions and the following disclaimer.

  * Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.

  * Neither the name of the copyright holder nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  
  Author: Xianzhong Fang, Email: xzfangcs@163.com
*/



#include <iostream>
#include <boost/property_tree/ptree.hpp>
#include <unordered_set>
#include <minpack.h>

#include <zjucad/matrix/io.h>
#include <fxzlib_basic/mesh/reg_volmesh_creation.h>

#include "common.h"
#include "conn.h"
#include "metric3d.h"


#ifdef __cplusplus
    extern "C" {
#endif
      void cal_halfsymmat3_det_(double* det, const double* halfsymmat);
      void cal_mat3_det_(double* det, const double* mat3);
      void cal_inv_halfsymmat3_(double* inv_mat, const double* halfsymmat);
      void cal_inv_mat3_(double* inv_mat3, const double* mat3);
      void cal_conn_rot3d_rodri_(double* R, const double* conn);
      void cal_conn3d_with_a_(
          double* C, const double* ca, const double* cb, const double* cf,
          const double* fn, const double* LA, const double* LB);

#ifdef __cplusplus
    }
#endif

namespace fxz {

const size_t INVALID_NUM = (size_t)(-1);


#define CALL_FUNC(pn) {                         \
    if(pn){ return __LINE__; }}

int normalize_vec(double* v, size_t n, const std::string& str, double eps);

namespace io{
int read_matrix_with_binary(const std::string& file, fmatrixd& M);
}

namespace frame3d {

using namespace fxz::mesh;
using namespace zjucad::matrix;

const double kThetaEps = 1e-14;

////////////////////////////////////////////////////////////////////////
// calculate matrix determinant, and the input matrix is represented with half of symmetrical matrix
int cal_halfsymmat3_det(const fmatrixd& HM, double& det)
{
  if (HM.size() != 6) return 1;
  cal_halfsymmat3_det_(&det, &HM[0]);
  return 0;
}

// calculate matrix determinant
int cal_mat3_det(const fmatrixd& M, double& det)
{
  if (M.size() != 9) return 1;
  cal_mat3_det_(&det, &M[0]);
  return 0;
}

// calculate inverse matrix represented with half of symmetric matrix
int cal_inv_halfsymmat3(const fmatrixd& HM, fmatrixd& MI)
{
  MI.resize(3,3);
  if (HM.size() != 6) return 1;
  cal_inv_halfsymmat3_(&MI[0], &HM[0]);
  return 0;
}

// calculate inverse matrix MI of matrix M
int cal_inv_mat3(const fmatrixd& M, fmatrixd& MI)
{
  MI.resize(3,3);
  if (M.size() != 9) return 1;
  cal_inv_mat3_(&MI[0], &M[0]);
  return 0;
}

// calculate rotation matrix from Lie-algebra (sec 4.2)
int cal_conn_rot3d(const fmatrixd& conn, fmatrixd& R)
{
  assert(conn.size() == 3);
  R.resize(3,3);
  if (zjucad::matrix::norm(conn) < kThetaEps) {
    R = zjucad::matrix::eye<double>(3);
  } else {
    cal_conn_rot3d_rodri_(&R[0], &conn[0]);
  }

  return 0;
}

// get tet-mesh inner faces
int get_tet_inner_faces(const tet_mesh& tm, fmatrixst& inner_faces)
{
  std::unordered_set<size_t> face_id;

  size_t hf_num = tm.hfaces_num();

  for (size_t i = 0; i < hf_num; ++i) {
    tet_mesh::hface_handle hf(i);
    if (tm.is_bound(hf)) continue;
    auto op_hf = tm.oppo(hf);
    if (tm.is_bound(op_hf)) continue;
    if (face_id.find(hf.id()) != face_id.end()
        || face_id.find(op_hf.id()) != face_id.end()) continue;
    face_id.insert(hf.id());
  }

  inner_faces.resize(face_id.size());
  std::copy(face_id.begin(), face_id.end(), inner_faces.begin());

  return 0;
}

int get_tet_dual_edges(const tet_mesh& tm, fmatrixst& dual_edges)
{
  fmatrixst inner_faces;
  get_tet_inner_faces(tm, inner_faces);
  dual_edges.resize(2, inner_faces.size());

  size_t cnt = 0;
  for (auto hf_id : inner_faces) {
    tet_mesh::hface_handle hf(hf_id);
    dual_edges(0, cnt) = tm.vol(hf).id();
    dual_edges(1, cnt) = tm.vol(tm.oppo(hf)).id();
    ++cnt;
  }

  std::cout << "-- dual edge number: " << cnt << std::endl;

  return 0;
}

int read_conn3d(const std::string& in_file, std::vector<conn_data>& CR)
{
  std::ifstream inf(in_file);

  if (inf.fail()) {
    std::cerr << "-- [ ERROR ] can not open file: " << in_file << std::endl;
    return 1;
  }

  size_t N(INVALID_NUM);
  inf >> N;

  // clean the first line
  std::string S;
  std::getline(inf, S);
  
  if (std::isnan(N) || N == INVALID_NUM) {
    std::cerr << "-- [ ERROR ] the first number in the conn file is not right." << std::endl;
    inf.close();
    return 1;
  }
  std::cout << "-- dual edge number: " << N << std::endl;
  if (N==0) {
    std::cerr << "-- [ ERROR ] the first number is zero, not right." << std::endl;
    inf.close();
    return 1;
  }

  CR.clear();
  CR.reserve(N);
  
  for (size_t i = 0; i < N; ++i) {
    conn_data cd;
    if (!std::getline(inf, S)) {
      std::cerr << "-- [ ERROR ] cannot read line of conn file : " << i+1 << std::endl;
      return 1;
    }
    
    std::stringstream ss(S);
    if (ss >> cd.t[0] >> cd.t[1] >> cd.logr[0] >> cd.logr[1] >> cd.logr[2]) {
      if (std::isnan(cd.t[0]) || std::isnan(cd.t[1]) || std::isnan(cd.logr[0])
          || std::isnan(cd.logr[1]) || std::isnan(cd.logr[2])) {
        std::cerr << "-- [ ERROR ] exist nan value in the file." << std::endl;
        return 1;
      }
      CR.push_back(cd);
    } else {
      std::cerr << "-- [ ERROR ] cannot read values in conn, at line: " << i+1
                << ", the content is:\n\"" << S << "\"" << std::endl;
      return 1;
    }
  }

  inf.close();
  
  return 0;
}

int write_conn3d(const std::string& out_file, const std::vector<conn_data>& CR)
{
  std::ofstream outf(out_file);
  if (outf.fail()) {
    std::cerr << "-- [ ERROR ] can not open file: " << out_file << std::endl;
    return 1;
  }

  size_t N = CR.size();
  outf << N << std::endl;

  for (size_t i = 0; i < N; ++i) {
    if(std::isnan(CR[i].logr[0]) || std::isnan(CR[i].logr[1]) || std::isnan(CR[i].logr[2])) {
      std::cerr << "-- [ ERROR ] zyz is nan: t2 " << CR[i].t[0] << ", " << CR[i].t[1]
                << ", hfid: " << i << ", zyz: " << CR[i].logr[0] << ", " << CR[i].logr[1]
                << ", " << CR[i].logr[2] << std::endl;
      return 1;
    }
    
    outf << CR[i].t[0] << " " << CR[i].t[1]
         << " " << CR[i].logr[0] << " " << CR[i].logr[1]
         << " " << CR[i].logr[2] << std::endl;
  }

  outf.close();
  
  return 0;
}

int check_conn3d(const tet_mesh& tm, const std::vector<conn_data>& CR)
{
  size_t fn = tm.hfaces_num();
  size_t tn = tm.vols_num();

  size_t bound_fn = 0;
  for (size_t fi = 0; fi < fn; ++fi) {
    if (tm.is_bound(tet_mesh::hface_handle(fi))) {
      ++bound_fn;
    }
  }

  size_t inner_fn = fn/2-bound_fn;

#ifdef DEBUG_OUTPUT  
  std::cout << "-- faces       number: " << fn/2 << std::endl;
  std::cout << "-- inner faces number: " << fn/2-bound_fn << std::endl;
  std::cout << "-- CR          number: " << CR.size() << std::endl;
#endif  

  if (CR.size() != inner_fn) {
    std::cerr << "-- [ ERROR ] the conn is not compatible with tet mesh." << std::endl;
    return 1;
  }

  for (size_t fi = 0; fi < CR.size(); ++fi) {
    size_t ta = CR[fi].t[0];
    size_t tb = CR[fi].t[1];
    if (ta >= tn || tb >= tn) {
      std::cerr << "-- [ ERROR ] the conn is not right, exist dual edge has invalid face id:"
                << ta << ", " << tb << " ." << std::endl;
      return 1;
    }
    if (std::isnan(CR[fi].logr[0]) || std::isnan(CR[fi].logr[1])
        || std::isnan(CR[fi].logr[2])) {
      std::cerr << "-- [ ERROR ] the values in the conn is not right, exist nan value."
                << std::endl;
      return 1;
    }
  }

  return 0;
}

// calculate 3D connection along dual edge about two tets
// ca: left tet barycenter
// cb: right tet barycenter
// cf: center of inner face
// f_norm: inner face normal
// L_A: g^{1/2} in the left tet 
// L_A: g^{1/2} in the right tet
int integrate_conn_along_dual_edge(
    const fmatrixd& ca, const fmatrixd& cb, const fmatrixd& cf,
    const fmatrixd& f_norm, const fmatrixd& L_A, const fmatrixd& R_A,
    fmatrixd& conn)
{
  cal_conn3d_with_a_(&conn[0], &ca[0], &cb[0], &cf[0], &f_norm[0], &L_A[0], &R_A[0]);
  return 0;
}

// calculate 3D connection for each inner face.
int cal_conn_with_simple_gradient(
    const boost::property_tree::ptree& para,
    const tet_mesh& tm, const fmatrixd& A,
    const fmatrixst& inner_faces,
    std::vector<conn_data>& CR)
{
  CR.resize(inner_faces.size());

  const fmatrixd& V = tm.verts_coord();

#pragma omp parallel for
  for (size_t i = 0; i < static_cast<size_t>(inner_faces.size()); ++i) {
    tet_mesh::hface_handle hf(inner_faces[i]);
    tet_mesh::vol_handle ta(tm.vol(hf));
    tet_mesh::vol_handle tb(tm.vol(tm.oppo(hf)));

    conn_data& cd = CR[i];
    cd.t[0] = ta.id(); cd.t[1] = tb.id();

    std::vector<size_t> f_vs;
    tm.adj_verts(hf, f_vs);
    assert(f_vs.size() == 3);

    fmatrixd ca(3,1), cb(3,1);
    tm.tet_center(ta, ca);
    tm.tet_center(tb, cb);

    fmatrixd cf = (V(colon(),f_vs[0])+V(colon(),f_vs[1])+V(colon(),f_vs[2]))/3.0;
    fmatrixd f_normal = zjucad::matrix::cross(
        V(colon(),f_vs[2])-V(colon(),f_vs[0]), V(colon(),f_vs[1])-V(colon(),f_vs[0]));
    normalize_vec(&f_normal[0], 3, "half-face normal", kLengthEps);

    fmatrixd Co(3,1);
    fmatrixd left_A  = A(colon(), cd.t[0]);
    fmatrixd right_A = A(colon(), cd.t[1]);
    integrate_conn_along_dual_edge(ca, cb, cf, f_normal, left_A, right_A, Co);

    assert(zjucad::matrix::dot(f_normal, cb-ca) > 0.0);

    for (size_t k = 0; k < 3; ++k) {
      cd.logr[k] = Co[k];
    }

    if (std::isnan(cd.logr[0])||std::isnan(cd.logr[1])||std::isnan(cd.logr[2])) {
      std::cerr << "-- [ ERROR ] the conn value is nan, for dual edge: ("
                << ta.id() << ", " << tb.id() << ")\n"
                << "   Co: " << Co << std::endl;
      continue;
    }
  }

  return 0;
}


// calculate 3D connection with given metric field on a tet mesh.
int conn3d_maker(const boost::property_tree::ptree& para)
{
  const std::string in_tet = para.get<std::string>("in_tet.value"); // vtk
  const std::string in_S3d = para.get<std::string>("in_S3.value"); // binary mat
  const std::string out_conn = para.get<std::string>("out_conn.value"); // txt, zyz angle

  std::shared_ptr<tet_mesh> tet_ptr;
  // read input tet mesh
  CALL_FUNC(create_reg_volmesh(in_tet, tet_ptr));

  fmatrixd HAI;
  // read symmetric matrix g^{-1/2} on each tet (only store half of the symmetric matrix)
  CALL_FUNC(io::read_matrix_with_binary(in_S3d, HAI));

  if (static_cast<size_t>(HAI.size(1)) != 6) return 1;
  if (static_cast<size_t>(HAI.size(2)) != tet_ptr->vols_num()) {
    std::cerr << "-- [ ERROR ] the metric is not compatible with the input mesh." << std::endl;
    return 1;
  }

  fmatrixst inner_faces;
  // get inner faces for the input tet mesh
  CALL_FUNC(get_tet_inner_faces(*tet_ptr, inner_faces));

  fmatrixst DE;
  std::vector<conn_data> CR;
  fmatrixd& A = HAI;
  // transform g^{-1/2} to g^{1/2}
  CALL_FUNC(S_to_A(A));
  // calculate 3D connection with tet mesh and metric
  CALL_FUNC(cal_conn_with_simple_gradient(para, *tet_ptr, A, inner_faces, CR));
  CALL_FUNC(write_conn3d(out_conn, CR));
  std::cout << "-- Write connection into file: " << out_conn << std::endl;

  return 0;
}


} // namespace frame3d
} // namespace fxz

