/*
  This file is part of MetricDrivenFrame3D (Metric-Driven 3D Frame Field Generation).
  
  Copyright (C) 2022,  Xianzhong Fang
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

  * Redistributions of source code must retain the above copyright notice, this
  list of conditions and the following disclaimer.

  * Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.

  * Neither the name of the copyright holder nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  
  Author: Xianzhong Fang, Email: xzfangcs@163.com
*/



#include <unordered_map>
#include <unordered_set>
#include <omp.h>
#include <numeric>
#include <zjucad/matrix/io.h>
#include <fxzlib_basic/function/hj_func_opt.h>
#include <fxzlib_basic/mesh/reg_volmesh_creation.h>

#include "common.h"
#include "conn.h"
#include "reg_volmesh.h"
#include "converter.h"
#include "ffc3d.h"

namespace fxz {

#define CALL_FUNC(pn) {                         \
    if(pn){ return __LINE__; }}


int normalize_vec(double* v, size_t n, const std::string& str, double eps);

namespace common{
inline bool check_filename_ok(const std::string& filename)
{
  if (filename == "" || filename == "null" || filename == "none") return false;
  return true;
}
}

namespace io{
int read_matrix(const std::string& file, fmatrixd& M);
int read_matrix_with_binary(const std::string& file, fmatrixd& M);
int write_matrix(const std::string& file, const fmatrixd& M);
int write_matrix_with_binary(const std::string& file, const fmatrixd& M);
}

namespace frame3d{
  fxz::function::hj_func_di::FT* build_sh_grad_func(
      size_t dim_x, const double* R, size_t aid_s, size_t bid_s);
  fxz::function::hj_func_di::FT* build_zyz_grad_func(
      size_t dim_x, const double* R, size_t aid_start, size_t bid_start);
  fxz::function::hj_func_di::FT* build_sh_align_func(
      size_t dim_x, const double* sh_mat, size_t tid);
  fxz::function::hj_func_di::FT* build_zyz_align_func(
      size_t dim_x, const double* sh_mat, size_t tid);
  fxz::function::hj_func_di::FT* build_full_zyz_align_func(
      size_t dim_x, const double* sh, size_t tid);
  fxz::function::hj_func_di::FT* build_full_sh_align_func(
      size_t dim_x, const double* sh, size_t tid);
}

namespace function{
class func_set
{
 public:
  static hj_func_di::FT* vec_unit(size_t dim_x, size_t r, double len2, size_t id_start);
};
}

namespace solver {

int LM_solver(
    const boost::property_tree::ptree& para,
    const fxz::function::hj_func::FTP& obj_func,
    const std::vector<double>& weight,
    fmatrixd& X);

int bfgs_solver(
    const boost::property_tree::ptree& para,
    const fxz::function::hj_func_di::FTP& func,
    fmatrixd& X);
}
}


using namespace fxz;
using namespace fxz::mesh;
using namespace fxz::function;
using namespace zjucad::matrix;

namespace fxz {
namespace frame3d {


const double SMOOTH_WEI=1.0;

class cross3d_process
{
 public:
  cross3d_process(const boost::property_tree::ptree& para, const tet_mesh& tm,
                  const std::vector<size_t>& ffaces_id,
                  const cross_cons& align_cons,
                  const std::vector<conn_data>& cd, fmatrixd& zyz)
      : para_(para), tm_(tm), ffaces_id_(ffaces_id),
        align_cons_(align_cons), cd_(cd), zyz_(zyz), eps_(1e-9)
  { init(); }
  
  ~cross3d_process() {}

  typedef hj_func::FT* (*align_func_type)(size_t dim_x, const double* sh_mat, size_t tid);
  typedef hj_func::FT* (*grad_func_type)(size_t dim_x, const double* R, size_t aid_start, size_t bid_start);
  typedef hj_func::FT* (*cont_func_type)(size_t dim_x, const double* sh, size_t ta, size_t tb, double w);  

  int build_grad_func(
      size_t ty, grad_func_type grad_func_opt, hj_func::FTP& grad_func);
  int build_grad_func(
      size_t ty, grad_func_type grad_func_opt,
      hj_func::FTP_VP& grad_funcs, hj_func::DVP& W);
  
  int build_align_func(
      size_t dim_x, align_func_type align_func_opt, align_func_type full_align_func_opt,
      hj_func::FTP& hard_align_func, hj_func::FTP& soft_align_func);
  
  int build_align_func(
      size_t dim_x, align_func_type align_func_opt, align_func_type full_align_func_opt,
      hj_func::FTP_VP& hard_align_funcs, hj_func::DVP& HW,
      hj_func::FTP_VP& soft_align_funcs, hj_func::DVP& SW);
  
  int build_sh_unit_func(hj_func::FTP_VP& funcs, hj_func::DVP& W);
  int build_sh_unit_func(hj_func::FTP& sh_unit_func);

  int set_init_GN_solver_para(boost::property_tree::ptree& solver_para);
  int init_step_with_GN();
  
  int set_bfgs_solver_para(boost::property_tree::ptree& para);
  int bfgs_step();

  int sh_to_zyz(const fmatrixd& sh);

  void print_eps_error(const std::string& info)
  {
    std::cerr << "-- too small " << info << ", less than " << eps_ << std::endl;
  }

  int get_align_SH();

  int calculate_RH();

 private:
  int init();
  cross3d_process(const cross3d_process&) = delete;
  cross3d_process& operator=(const cross3d_process&) = delete;
  
 private:
  // basic input data
  const boost::property_tree::ptree& para_;
  const tet_mesh& tm_;
  const std::vector<size_t>& ffaces_id_;
  const cross_cons& align_cons_;
  const std::vector<conn_data>& cd_;
  fmatrixd& zyz_;
  short is_surf_unit_;
  short is_surf_smooth_;
  double eps_;

 private:
  fmatrixd align_d2z_SH_, align_SH_, CR_;
  double sh_hard_cons_wei_, zyz_hard_cons_wei_, soft_cons_wei_;
  size_t sh_dim_x_;
};


int cross3d_process::init()
{
  sh_hard_cons_wei_ = para_.get<double>("sh_hard_cons_wei.value", 1e2);
  zyz_hard_cons_wei_ = para_.get<double>("zyz_hard_cons_wei.value", 1e3);
  soft_cons_wei_ = para_.get<double>("soft_cons_wei.value", 1.0);

#ifdef DEBUG_OUTPUT  
  std::cout << "[table]  sh-hard-cons-wei " << sh_hard_cons_wei_ << std::endl;
  std::cout << "[table] zyz-hard-cons-wei " << zyz_hard_cons_wei_ << std::endl;
  std::cout << "[table]    soft-cons-wei " << soft_cons_wei_ << std::endl;
#endif  
  
  size_t tn = tm_.vols_num();
  if (zyz_.size() == 0) {
    zyz_ = zjucad::matrix::zeros<double>(3, tn);
  }


  CALL_FUNC(get_align_SH());
  
  sh_dim_x_ = 9*tn;

#ifdef DEBUG_OUTPUT  
  {
    size_t d_num = align_d2z_SH_.size(2);
    size_t r_num = align_SH_.size(2);
    std::cout << "[table] R-direc-cons-num " << d_num << std::endl;
    std::cout << "[table]  R-full-cons-num " << r_num << std::endl;
  }
#endif  
  
  return 0;
}


int logR_to_zyz(const fmatrixd& C, double* zyz)
{
  fmatrixd R(3, 3);
  cal_conn_rot3d(C, R);
  vfg_fxz::converter::one_rot_mat_to_zyz(&R[0], zyz);
  return 0;
}

int logR_to_zyz(const double* C, double* zyz)
{
  fmatrixd MC(3,1);
  MC[0] = C[0];
  MC[1] = C[1];
  MC[2] = C[2];
  return logR_to_zyz(MC, zyz);
}

int cross3d_process::calculate_RH()
{
  CR_.resize(81, cd_.size());
  for (size_t i = 0; i < cd_.size(); ++i) {
    fmatrixd Co(3,1);
    for (size_t k = 0; k < 3; ++k) {
      Co[k] = cd_[i].logr[k];
    }
    double temp_zyz[3];
    logR_to_zyz(&Co[0], temp_zyz);
    vfg_fxz::converter::one_zyz_to_sh_mat(temp_zyz, &CR_[81*i]);
  }

  return 0;
}

int cross3d_process::get_align_SH()
{
  size_t d_num = align_cons_.D_num();
  size_t r_num = align_cons_.R_num();  

#ifdef DEBUG_OUTPUT  
  std::cout << "-- align direction num: " << d_num << std::endl;
  std::cout << "-- full align num: " << r_num << std::endl;
#endif  
  
  align_d2z_SH_.resize(81, d_num);
  align_SH_.resize(9, r_num);

  for (size_t di = 0; di < d_num; ++di) {
    fmatrixd norm_zyz(3);
    auto& D = align_cons_.D(di);
    vfg_fxz::converter::one_norm_to_zaxis_zyz(&D[0], &norm_zyz[0]);
    vfg_fxz::converter::one_zyz_to_sh_mat(&norm_zyz[0], &align_d2z_SH_[81*di]);
  }

  for (size_t ri = 0; ri < r_num; ++ri) {
    auto& R = align_cons_.R(ri);
    fmatrixd zyz(3);
    fmatrixd H(9,9);
    vfg_fxz::converter::one_rot_mat_to_zyz(&R[0], &zyz[0]);
    vfg_fxz::converter::one_zyz_to_sh(&zyz[0], &align_SH_[9*ri]);
  }

  return 0;
}

int cross3d_process::build_align_func(
    size_t dim_x, align_func_type align_func_opt, align_func_type full_align_func_opt,
    hj_func::FTP_VP& all_hard_funcs, hj_func::DVP& HW,
    hj_func::FTP_VP& all_soft_funcs, hj_func::DVP& SW)
{
  if (HW->size() != 0) { return 1; }
  if (SW->size() != 0) { return 1; }
  
  size_t d_num = align_d2z_SH_.size(2);
  size_t r_num = align_SH_.size(2);

  assert(cast_to_size(align_d2z_SH_.size()) == 81*d_num);

  for (size_t di = 0; di < d_num; ++di) {
    assert(81*di < cast_to_size(align_d2z_SH_.size()));
    assert(align_cons_.D_t(di) < tm_.vols_num());

    hj_func::FTP f(align_func_opt(dim_x, &align_d2z_SH_[81*di], align_cons_.D_t(di)));
    double w = align_cons_.D_w(di);
    if (w < 0.0) {
      all_hard_funcs->push_back(f);
      for (size_t i = 0; i < f->nf(); ++i) {
        HW->push_back(1.0);
      }
    } else {
      all_soft_funcs->push_back(f);
      for (size_t i = 0; i < f->nf(); ++i) {
        SW->push_back(w);
      }
    }
  }

  for (size_t ri = 0; ri < r_num; ++ri) {
    assert(align_cons_.R_t(ri) < tm_.vols_num());
    hj_func::FTP f(full_align_func_opt(dim_x, &align_SH_[9*ri], align_cons_.R_t(ri)));
    double w = align_cons_.R_w(ri);
    if (w < 0.0) {
      all_hard_funcs->push_back(f);
      for (size_t i = 0; i < f->nf(); ++i) {
        HW->push_back(1.0);
      }
    } else {
      all_soft_funcs->push_back(f);
      for (size_t i = 0; i < f->nf(); ++i) {
        SW->push_back(w);
      }
    }
  }


  const double common_w = static_cast<double>(all_hard_funcs->size()+all_soft_funcs->size());

  if (all_hard_funcs->size() > 0) {
    for (size_t i=0; i<HW->size(); ++i) {
      (*HW)[i] = sqrt((*HW)[i]/common_w);
    }
  }

  if (all_soft_funcs->size() > 0) {
    for (size_t i=0; i<SW->size(); ++i) {
      (*SW)[i] = sqrt((*SW)[i]/common_w);
    }
  }

  return 0;
}

int cross3d_process::build_align_func(
    size_t dim_x, align_func_type align_func_opt, align_func_type full_align_func_opt,
    hj_func::FTP& hard_align_func, hj_func::FTP& soft_align_func)
{
  hj_func::FTP_VP all_hard_funcs(new hj_func::FTP_V);
  hj_func::FTP_VP all_soft_funcs(new hj_func::FTP_V);
  hj_func::DVP SW(new hj_func::DV), HW(new hj_func::DV);

  CALL_FUNC(build_align_func(
      dim_x, align_func_opt, full_align_func_opt,
      all_hard_funcs, HW, all_soft_funcs, SW));

  if (all_hard_funcs->size() > 0) {
    hj_func::sumsqr(all_hard_funcs, HW, hard_align_func);
  } else {
    std::cerr << "-- [ ERROR ] the boundary alignment is not set." << std::endl;
    return 1;
  }
  
  if (all_soft_funcs->size() > 0) {
    hj_func::sumsqr(all_soft_funcs, SW, soft_align_func);
  }

  return 0;
}

int cross3d_process::build_sh_unit_func(
    hj_func::FTP_VP& funcs, hj_func::DVP& W)
{
  size_t tn = tm_.vols_num();
  if (tn==0) return 1;

  const double wei = sqrt(1.0/static_cast<double>(tn));
  for (size_t ti = 0; ti < tn; ++ti) {
    funcs->push_back(hj_func::FTP(func_set::vec_unit(sh_dim_x_, 9, 12.0, 9*ti)));
    W->push_back(wei);
  }

  return 0;
}

int cross3d_process::build_sh_unit_func(hj_func::FTP& sh_unit_func)
{
  size_t tn = tm_.vols_num();
  if (tn==0) return 1;
  
  hj_func::FTP_VP all_funcs(new hj_func::FTP_V);
  hj_func::DVP W(new hj_func::DV);
  all_funcs->reserve(tn);
  W->reserve(tn);
  CALL_FUNC(build_sh_unit_func(all_funcs, W));
  hj_func::sumsqr(all_funcs, W, sh_unit_func);

  return 0;
}


int cross3d_process::build_grad_func(
    size_t ty, grad_func_type grad_func_opt,
    hj_func::FTP_VP& all_funcs,
    hj_func::DVP& W)
{
  size_t start_size = W->size();
  
  size_t dim_x = ty*tm_.vols_num();

  size_t tn = tm_.vols_num();
  fmatrixd cens(3, tn);
  fmatrixd volumes(1, tn);
  for (size_t ti = 0; ti < tn; ++ti) {
    fmatrixd c(3,1);
    tm_.tet_center(mesh::tet_mesh::vol_handle(ti), c);
    cens(colon(), ti) = c;
    volumes[ti] = tm_.tet_volume(mesh::tet_mesh::vol_handle(ti));
  }

  const double all_volume = std::accumulate(volumes.begin(), volumes.end(), 0.0);

  double all_wei = 0.0;

  std::set<std::pair<size_t,size_t> > ffaces_pair;
  for (auto f : ffaces_id_) {
    tet_mesh::hface_handle fh(f);
    if (tm_.is_bound(fh)) continue;
    std::pair<size_t, size_t> t2(tm_.vol(fh).id(), tm_.vol(tm_.oppo(fh)).id());
    if (t2.first == tet_mesh::INVALID_ID || t2.second == tet_mesh::INVALID_ID) {
      continue;
    }
    if (t2.first > t2.second) std::swap(t2.first, t2.second);
    ffaces_pair.insert(t2);
  }

  for (size_t fi = 0; fi < cd_.size(); ++fi) {
    size_t ta = cd_[fi].t[0];
    size_t tb = cd_[fi].t[1];
    {
      std::pair<size_t,size_t> t2(ta, tb);
      if (t2.first > t2.second) std::swap(t2.first, t2.second);
      if (ffaces_pair.find(t2) != ffaces_pair.end()) continue; // feature faces.
    }
    
    assert(81*fi < cast_to_size(CR_.size()));
    hj_func::FTP f(grad_func_opt(dim_x, &CR_[81*fi], ty*ta, ty*tb));
    all_funcs->push_back(f);
    double wei = norm(cens(colon(),ta)-cens(colon(),tb));

    double add_eps = 0.0;
    if (wei < eps_) {
      std::cerr << "-- [ WARNING ] tet distance is very small, add "
                << eps_ << " !!! "
                << " (" << ta << ", " << tb << std::endl;
      add_eps = eps_;
    }
    wei = (fabs(volumes[ta])+fabs(volumes[tb]))/(wei*wei+add_eps);

    for (size_t i=0; i<f->nf(); ++i) { W->push_back(wei);}
    all_wei += wei;
  }

  double vol3 = pow(all_volume, 1.0/3.0);
  for (size_t i=start_size; i<W->size(); ++i) {
    (*W)[i] = sqrt((*W)[i]/vol3);
  }

  return 0;
}

int cross3d_process::build_grad_func(
    size_t ty, grad_func_type grad_func_opt, hj_func::FTP& grad_func)
{
  hj_func::FTP_VP all_funcs(new hj_func::FTP_V);
  hj_func::DVP W(new hj_func::DV);

  all_funcs->reserve(cd_.size());
  W->reserve(cd_.size()*9);

  CALL_FUNC(build_grad_func(ty, grad_func_opt, all_funcs, W));

  hj_func::sumsqr(all_funcs, W, grad_func);

  return 0;
}

int cross3d_process::set_bfgs_solver_para(boost::property_tree::ptree& solver_para)
{
  size_t iter = para_.get<size_t>("bfgs_iter.value", 500);
  double epsg = para_.get<double>("bfgs_epsg.value", 1e-3);
  double epsf = para_.get<double>("bfgs_epsf.value", 1e-3);

  solver_para.put("lbfgs-len.value", 7);
  solver_para.put("iter.value", iter);
  solver_para.put("epsg.value", epsg);
  solver_para.put("epsf.value", epsf);

#ifdef DEBUG_OUTPUT  
  std::cout << "# [ SET bfgs Parameters ]" << std::endl;
  std::cout << "-- max iter num: " << iter << std::endl;
  std::cout << "-- epsg        : " << epsg << std::endl;
#endif  

  
  return 0;
}

int cross3d_process::init_step_with_GN()
{
  CALL_FUNC(calculate_RH());

  bool is_using_reg = true;

  std::vector<size_t> start_ids;
  std::vector<double> global_w;
  start_ids.reserve(4);
  global_w.reserve(4);
  {
    global_w.push_back(sqrt(SMOOTH_WEI));
    global_w.push_back(sqrt(sh_hard_cons_wei_));
    global_w.push_back(sqrt(soft_cons_wei_));
  }
  
  hj_func::FTP_VP all_funcs(new hj_func::FTP_V);
  hj_func::DVP W(new hj_func::DV);

  CALL_FUNC(build_grad_func(9, build_sh_grad_func, all_funcs, W));

  for (auto& w : *W) {
    w *= global_w[0];
  }

  { // add align funcs
    hj_func::FTP_VP hard_funcs(new hj_func::FTP_V), soft_funcs(new hj_func::FTP_V);
    hj_func::DVP HW(new hj_func::DV), SW(new hj_func::DV);
    CALL_FUNC(build_align_func(
        sh_dim_x_, build_sh_align_func,
        build_full_sh_align_func,
        hard_funcs, HW, soft_funcs, SW));
    
    for (auto& f : *hard_funcs) { all_funcs->push_back(f); }
    for (auto& w : *HW) { W->push_back(w*global_w[1]); }
    for (auto& f : *soft_funcs) { all_funcs->push_back(f); }
    for (auto& w : *SW) { W->push_back(w*global_w[2]); }
  }

  if (is_using_reg) {
    const double sh_reg_wei = para_.get<double>("sh_reg_wei.value", 1e-2);
    global_w.push_back(sqrt(sh_reg_wei));

    size_t w_start = W->size();
    CALL_FUNC(build_sh_unit_func(all_funcs, W));
    for (size_t i = w_start; i < W->size(); ++i) {
      (*W)[i] *= global_w.back();
    }
  }

  fmatrixd x(9, sh_dim_x_/9);

  std::fill(x.begin(), x.end(), 0.0);

  boost::property_tree::ptree solver_para;
  set_init_GN_solver_para(solver_para);

  
  hj_func::FTP obj_func(nullptr);
  hj_func::cat(all_funcs, obj_func);
  CALL_FUNC(solver::LM_solver(solver_para, obj_func, *W, x));

  return sh_to_zyz(x);
}

int cross3d_process::set_init_GN_solver_para(boost::property_tree::ptree& solver_para)
{
  size_t iter = para_.get<size_t>("init_iter.value", 100);
  double epsg = para_.get<double>("init_epsg.value", 1e-3);
  
  solver_para.put("iter.value", iter);
  solver_para.put("maxits.value", 100);
  solver_para.put("epsg.value", epsg);
  solver_para.put("epsf.value", 1e-4);
  solver_para.put("epsx.value", 1e-4);

#ifdef DEBUG_OUTPUT  
  std::cout << "# [ SET INIT Parameters ]" << std::endl;
  std::cout << "-- max iter num : " << iter << std::endl;
  std::cout << "-- epsg         : " << epsg << std::endl;
#endif  

  return 0;
}

int cross3d_process::sh_to_zyz(const fmatrixd& sh)
{
  size_t tn = tm_.vols_num();
  size_t ti(0);
#pragma omp parallel for private(ti)
  for (ti=0; ti<tn; ++ti) {
    vfg_fxz::converter::one_sh_to_zyz(&sh[9*ti], &zyz_[3*ti]);
  }

#pragma omp parallel for private(ti)
  for (ti=0; ti<tn; ++ti) {
    std::vector<size_t> adj_ts;
    tm_.adj_vols(tet_mesh::vol_handle(ti), adj_ts);
    
    fmatrixd adj_zyz(3, adj_ts.size());
    for (size_t j = 0; j < adj_ts.size(); ++j) {
      assert(adj_ts[j] < cast_to_size(zyz_.size(2)));
      adj_zyz(colon(), j) = zyz_(colon(), adj_ts[j]);
      vfg_fxz::converter::one_sh_to_zyz(&sh[9*ti], &adj_zyz[3*j]);
    }
    
    fmatrixd fH(9, 1);
    vfg_fxz::converter::one_zyz_to_sh(&zyz_[3*ti], &fH[0]);
    double min_error = zjucad::matrix::norm(fH - sh(colon(), ti));
    
    for (size_t j = 0; j < adj_ts.size(); ++j) {
      vfg_fxz::converter::one_zyz_to_sh(&adj_zyz[3*j], &fH[0]);
      double error = zjucad::matrix::norm(fH - sh(colon(), ti));
      
      if (error < min_error) {
        min_error = error;
        assert(ti*3 < cast_to_size(zyz_.size()));
        zyz_(colon(), ti) = adj_zyz(colon(), j);
      }
    }
  }

  return 0;
}

int cross3d_process::bfgs_step()
{
  hj_func::FTP_VP all_funcs(new hj_func::FTP_V);
  hj_func::DVP W(new hj_func::DV);

  hj_func::FTP grad_func, hard_align_func(nullptr), soft_align_func(nullptr);
  CALL_FUNC(build_grad_func(3, build_zyz_grad_func, grad_func));
  
  CALL_FUNC(build_align_func(sh_dim_x_/3, build_zyz_align_func, build_full_zyz_align_func,
                             hard_align_func, soft_align_func));

  all_funcs->reserve(4); W->reserve(4);
  
  all_funcs->push_back(grad_func); W->push_back(SMOOTH_WEI);

  if (hard_align_func != nullptr) {
    all_funcs->push_back(hard_align_func); W->push_back(zyz_hard_cons_wei_);
  }
  
  if (soft_align_func != nullptr) {
    all_funcs->push_back(soft_align_func); W->push_back(soft_cons_wei_);
  }
  
  hj_func::FTP obj_func; hj_func::sum(all_funcs, W, obj_func);
  boost::property_tree::ptree solver_para;
  set_bfgs_solver_para(solver_para);

  solver::bfgs_solver(solver_para, obj_func, zyz_);

  return 0;
}

int cross_field3d_generation(
    const boost::property_tree::ptree& para,
    const tet_mesh& tm,
    const std::vector<size_t>& ffaces_id,
    const cross_cons& cross_cons,
    const fmatrixd& HS, const std::vector<conn_data>& CR,
    fmatrixd& zyz)
{
  size_t tn = tm.vols_num();
  fmatrixd cens(3, tn);
  for (size_t i=0; i<tn; ++i) {
    fmatrixd c(3);
    tm.tet_center(tet_mesh::vol_handle(i), c);
    cens(colon(), i) = c;
  }

  cross3d_process pro(para, tm, ffaces_id, cross_cons, CR, zyz);

  const std::string out_ff = para.get<std::string>("out_ff3.value");

  CALL_FUNC(pro.init_step_with_GN());
  CALL_FUNC(pro.bfgs_step());

  return 0;
}

int init_halfmatrix_with_identity(size_t tn, fmatrixd& HM)
{
  fmatrixd g(6,1);
  g[0] = g[3] = g[5] = 1.0;
  g[1] = g[2] = g[4] = 0.0;
  HM.resize(6, tn);
  for (size_t i = 0; i < tn; ++i) {
    HM(colon(),i) = g;
  }
  return 0;
}

int S_to_A(fmatrixd& S);
int cal_conn_with_simple_gradient(
    const boost::property_tree::ptree& para,
    const tet_mesh& tm, const fmatrixd& A,
    const fmatrixst& inner_faces,
    std::vector<conn_data>& CR);

int frame3d_maker(const boost::property_tree::ptree& para)
{
  const std::string in_tet = para.get<std::string>("in_tet.value"); // *.vtk
  const std::string in_ffc = para.get<std::string>("in_ffc3.value", "null"); // *.ffc3
  const std::string in_S = para.get<std::string>("in_S3.value", "null"); //*.S3
  const std::string out_ff = para.get<std::string>("out_ff3.value");  // *.ff3

  std::shared_ptr<tet_mesh> tet_ptr;
  CALL_FUNC(create_reg_volmesh(in_tet, tet_ptr));

#ifdef DEBUG_OUTPUT  
  std::cout << "[table] tet-num " << tet_ptr->vols_num() << std::endl;
  std::cout << "[table] vert-num " << tet_ptr->verts_num() << std::endl;
#endif  

  ff3d_cons_set ffc;
  if (fxz::common::check_filename_ok(in_ffc)) {
    CALL_FUNC(read_ffc3d(in_ffc, ffc));
  }

  std::vector<size_t> ffaces_id;

  size_t tn = tet_ptr->vols_num();

  fmatrixd HS;
  if (fxz::common::check_filename_ok(in_S)) {
    CALL_FUNC(io::read_matrix_with_binary(in_S, HS));
  } else {
    std::cout << "# There is no input metric." << std::endl;
    CALL_FUNC(init_halfmatrix_with_identity(tn, HS));
  }

  std::vector<conn_data> CR;
  {
    fmatrixst inner_faces;
    CALL_FUNC(get_tet_inner_faces(*tet_ptr, inner_faces));
    fmatrixst DE;
    fmatrixd A = HS;
    CALL_FUNC(S_to_A(A));
    CALL_FUNC(cal_conn_with_simple_gradient(para, *tet_ptr, A, inner_faces, CR));
  }

  CALL_FUNC(check_conn3d(*tet_ptr, CR));

  cross_cons ccons; // weight > 0, soft; weight < 0, hard.
  CALL_FUNC(extract_cross_cons_with_ffc(para, *tet_ptr, ffc, HS, ccons));

  fmatrixd ZYZ(3, tet_ptr->vols_num());
  std::fill(ZYZ.begin(), ZYZ.end(), 0.0);
  
  CALL_FUNC(cross_field3d_generation(para, *tet_ptr, ffaces_id, ccons, HS, CR, ZYZ));

  fmatrixd F(9, tn);
  for (size_t i = 0; i < tn; ++i) {
    fmatrixd S(3,3);
    halfmat3_to_mat3(&HS[6*i], &S[0]);
    fmatrixd R(3,3);
    vfg_fxz::converter::one_zyz_to_rot_mat(&ZYZ[3*i], &R[0]);
    fmatrixd fr = S*R;
    F(colon(), i) = fr(colon());
  }

  CALL_FUNC(io::write_matrix_with_binary(out_ff, F));
  std::cout << "-- write ff into : " << out_ff << std::endl;

  return 0;
}

int matrix_binary_to_ascii(const boost::property_tree::ptree& para)
{
  const std::string in_mat = para.get<std::string>("in_mat.value");
  const std::string out_mat = para.get<std::string>("out_mat.value");
  fmatrixd M;
  CALL_FUNC(io::read_matrix_with_binary(in_mat, M));
  CALL_FUNC(io::write_matrix(out_mat, M));
  return 0;
}

int matrix_ascii_to_binary(const boost::property_tree::ptree& para)
{
  const std::string in_mat = para.get<std::string>("in_mat.value");
  const std::string out_mat = para.get<std::string>("out_mat.value");
  fmatrixd M;
  CALL_FUNC(io::read_matrix(in_mat, M));
  CALL_FUNC(io::write_matrix_with_binary(out_mat, M));
  return 0;
}

} // namespace frame3d
} // namespace fxz
